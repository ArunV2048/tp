Place the JavaFX SDK 17.0.7 lib jars for this OS in the javafx/lib folder.
Download SDKs from: https://gluonhq.com/products/javafx/
Run:
- mac/linux: ./run
- windows:   run.bat
